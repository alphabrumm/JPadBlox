import{C as g,i as f,e as y}from"./jpad-WdTFZnka.js";import"./pixi.js-C5ePIoOa.js";import"./eventemitter3-_gqcMBhN.js";import"./earcut-CD8fr5l-.js";import"./ismobilejs-CHLuctl-.js";import"./pixi-fQzusUms.js";import"./parse-svg-path-Cnvz6UZS.js";import"./monaco-editor-BN5ojk0i.js";/* empty css                          *//* empty css                       */import"./codemirror-DF63iWqd.js";import"./style-mod-B5SJdkij.js";import"./crelt-C8TCjufn.js";import"./marijn-pSz78PDA.js";import"./w3c-keyname-Vcq4gwWv.js";import"./jquery-C2QK6WZq.js";import"./dragdroptouch-B-sHm6CJ.js";import"./howler-C2pz4j1R.js";import"./chalk-D1XV3AHK.js";import"./three-CnfRzQzS.js";import"./upng-js-ZDZbSSO5.js";import"./p5-Bvhh6uli.js";import"./mqtt-DrK7k_qv.js";import"./pako-COTvSS4P.js";import"./jszip-DdQ8jG3Z.js";import"./diff-match-patch-BF5algnu.js";import"./regular-table-CV9C_f8m.js";import"./markdown-it-lml7D-1Y.js";import"./mdurl-k9Sl0PQj.js";import"./uc.micro-kMc2yuuw.js";import"./entities-DOYUvOU8.js";import"./linkify-it-swVJLcMX.js";import"./punycode.js-Dj65hjkv.js";function j(c,s){const l=s>>16&255,t=s>>8&255,i=s&255,r=l/255,d=t/255,m=i/255,n=Math.max(r,d,m),h=Math.min(r,d,m),u=(n+h)/2;let p=0,b=0;if(n!=h){const o=n-h;b=u>.5?o/(2-n-h):o/(n+h),n==r?p=(d-m)/o+(d<m?6:0):n==d?p=(m-r)/o+2:p=(r-d)/o+4,p*=60}const e="#"+s.toString(16).padStart(6,"0").toUpperCase();return{name:c,hex:e,r:l,g:t,b:i,h:p,s:b,l:u}}function v(c,s){const l=c.s<.12,t=s.s<.12;if(l!=t)return l?1:-1;if(l)return s.l-c.l;const i=Math.round(c.h/15),r=Math.round(s.h/15);return i!=r?i-r:s.l-c.l}function oe(c,s){const l=Object.entries(g.predefinedColors).map(([e,o])=>j(e,o)),t=document.createElement("div");t.className="jp-sheet-layer jp-handbook-layer",t.innerHTML=`
        <div class="jp-handbook jp-colors" role="dialog" aria-modal="true" aria-label="Color Handbuch">
            <header class="jp-handbook-head">
                <h2>Color Handbuch</h2>
                <span class="jp-handbook-count"></span>
                <button class="jp-iconbtn jp-handbook-close" aria-label="Schließen">${f("close")}</button>
            </header>
            <div class="jp-sprite-example">
                <p class="jp-color-intro">Farben wählst du über die Klasse <code>Color</code>, z. B. für Füllung und Rand einer Figur:</p>
                <pre><span class="tok-type">Circle</span> c = <span class="tok-kw">new</span> <span class="tok-type">Circle</span>(<span class="tok-num">200</span>, <span class="tok-num">150</span>, <span class="tok-num">50</span>);
c.<span class="tok-fn">setFillColor</span>(<span class="tok-type">Color</span>.green);
c.<span class="tok-fn">setBorderColor</span>(<span class="tok-type">Color</span>.darkslategray);</pre>
                <p>Tippe auf eine Farbe, um <code>Color.name</code> zu kopieren.</p>
            </div>
            <div class="jp-color-tools">
                <label class="jp-handbook-search">
                    ${f("search")}
                    <input type="search" placeholder="Farbe suchen, z. B. blue, gray, rot"
                        autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="search">
                </label>
                <div class="jp-segmented jp-color-sort" role="group" aria-label="Sortierung">
                    <button data-sort="name" aria-pressed="true"><span>A–Z</span></button>
                    <button data-sort="hue" aria-pressed="false"><span>Farbton</span></button>
                </div>
            </div>
            <div class="jp-handbook-list jp-color-list"></div>
            <p class="jp-handbook-source">Farbwerte aus der Klasse Color der Online-IDE von Martin Pabst.</p>
        </div>`,c.appendChild(t),requestAnimationFrame(()=>t.classList.add("is-open"));const i=t.querySelector(".jp-color-list"),r=t.querySelector("input"),d=t.querySelector(".jp-handbook-count");let m="name";const n=()=>{t.classList.remove("is-open"),document.removeEventListener("keydown",h),setTimeout(()=>t.remove(),200)},h=e=>{e.key=="Escape"&&n()};document.addEventListener("keydown",h),t.querySelector(".jp-handbook-close").addEventListener("click",n),t.addEventListener("click",e=>{e.target==t&&n()});const u={rot:e=>e.s>.25&&(e.h<15||e.h>=345),orange:e=>e.s>.25&&e.h>=15&&e.h<40,gelb:e=>e.s>.25&&e.h>=40&&e.h<70,grün:e=>e.s>.2&&e.h>=70&&e.h<170,gruen:e=>e.s>.2&&e.h>=70&&e.h<170,blau:e=>e.s>.2&&e.h>=170&&e.h<255,lila:e=>e.s>.2&&e.h>=255&&e.h<300,violett:e=>e.s>.2&&e.h>=255&&e.h<300,pink:e=>e.s>.25&&e.h>=300&&e.h<345,rosa:e=>e.s>.25&&(e.h>=300||e.h<15)&&e.l>.6,grau:e=>e.s<.12,braun:e=>e.h>=10&&e.h<45&&e.l<.5&&e.s>.2},p=()=>{const e=r.value.trim().toLowerCase();let o=l.filter(a=>!e||a.name.toLowerCase().includes(e)||a.hex.toLowerCase().includes(e)||(u[e]?u[e](a):!1));o=o.sort(m=="name"?(a,k)=>a.name.localeCompare(k.name):v),i.innerHTML=o.length==0?`<div class="jp-empty">${f("search")}<p>Keine Farbe gefunden für „${y(r.value.trim())}“.</p></div>`:`<div class="jp-color-grid">${o.map(a=>`
                <button class="jp-color-item" data-name="${a.name}" aria-label="Color.${a.name}, ${a.hex}">
                    <span class="jp-color-swatch" style="background:${a.hex}"></span>
                    <span class="jp-color-text">
                        <span class="jp-color-name"><span class="tok-type">Color</span>.${a.name}</span>
                        <span class="jp-color-hex">${a.hex} · ${a.r}, ${a.g}, ${a.b}</span>
                    </span>
                </button>`).join("")}</div>`,d.textContent=e?`${o.length} von ${l.length} Farben`:`${l.length} Farben`};t.querySelectorAll("[data-sort]").forEach(e=>e.addEventListener("click",()=>{m=e.dataset.sort,t.querySelectorAll("[data-sort]").forEach(o=>o.setAttribute("aria-pressed",String(o==e))),p()})),i.addEventListener("click",async e=>{const o=e.target.closest("[data-name]");if(!o)return;const a="Color."+o.dataset.name;try{await navigator.clipboard.writeText(a),s(`Kopiert: ${a}`,"check")}catch{s(a,"info")}i.querySelectorAll(".is-copied").forEach(k=>k.classList.remove("is-copied")),o.classList.add("is-copied")});let b;r.addEventListener("input",()=>{clearTimeout(b),b=setTimeout(p,100)}),p()}export{oe as openColorBook};
