import{i as b,s as S,b as v,e as u}from"./jpad-C8XUnl7U.js";import"./pixi.js-C5ePIoOa.js";import"./eventemitter3-_gqcMBhN.js";import"./earcut-CD8fr5l-.js";import"./ismobilejs-CHLuctl-.js";import"./pixi-fQzusUms.js";import"./parse-svg-path-Cnvz6UZS.js";import"./monaco-editor-BN5ojk0i.js";/* empty css                          *//* empty css                       */import"./codemirror-DKieSu7B.js";import"./style-mod-B5SJdkij.js";import"./crelt-C8TCjufn.js";import"./marijn-pSz78PDA.js";import"./w3c-keyname-Vcq4gwWv.js";import"./jquery-C2QK6WZq.js";import"./dragdroptouch-B-sHm6CJ.js";import"./howler-C2pz4j1R.js";import"./chalk-D1XV3AHK.js";import"./three-CnfRzQzS.js";import"./upng-js-ZDZbSSO5.js";import"./p5-Bvhh6uli.js";import"./mqtt-DrK7k_qv.js";import"./pako-COTvSS4P.js";import"./jszip-DdQ8jG3Z.js";import"./diff-match-patch-BF5algnu.js";import"./regular-table-CV9C_f8m.js";import"./markdown-it-lml7D-1Y.js";import"./mdurl-k9Sl0PQj.js";import"./uc.micro-kMc2yuuw.js";import"./entities-DOYUvOU8.js";import"./linkify-it-swVJLcMX.js";import"./punycode.js-Dj65hjkv.js";const x=76,L=4;let k=null;async function w(){if(k)return k;const l=await(await fetch(S)).json(),c=new Map;for(const p of Object.keys(l.frames)){const o=p.match(/^(.*)#(\d+)$/);if(!o)continue;const n=l.frames[p].frame;c.has(o[1])||c.set(o[1],[]),c.get(o[1]).push({index:parseInt(o[2]),x:n.x,y:n.y,w:n.w,h:n.h})}const t=[];c.forEach((p,o)=>t.push({name:o,frames:p.sort((n,m)=>n.index-m.index)}));const r=new Image;return r.src=v,await r.decode(),k={sets:t,sheetW:r.naturalWidth,sheetH:r.naturalHeight},k}async function re(){return new Set((await w()).sets.map(l=>l.name))}async function oe(l,c){const t=document.createElement("div");t.className="jp-sheet-layer jp-handbook-layer",t.innerHTML=`
        <div class="jp-handbook jp-sprites" role="dialog" aria-modal="true" aria-label="Sprite Bibliothek">
            <header class="jp-handbook-head">
                <h2>Sprite Bibliothek</h2>
                <span class="jp-handbook-count"></span>
                <button class="jp-iconbtn jp-handbook-close" aria-label="Schließen">${b("close")}</button>
            </header>
            <div class="jp-sprite-example">
                <pre><span class="tok-type">Sprite</span> s = <span class="tok-kw">new</span> <span class="tok-type">Sprite</span>(<span class="tok-num">100</span>, <span class="tok-num">150</span>, <span class="tok-type">SpriteLibrary</span>.Minesweeper, <span class="tok-num">3</span>);</pre>
                <p>Erzeugt an der Stelle (100 | 150) ein Sprite mit Bild Nr. 3 der Reihe „Minesweeper“.
                Tippe auf ein Bild, um den passenden Code zu kopieren.</p>
            </div>
            <label class="jp-handbook-search">
                ${b("search")}
                <input type="search" placeholder="Reihe suchen, z. B. Minesweeper, Space, Bird"
                    autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" enterkeyhint="search">
            </label>
            <div class="jp-handbook-list jp-sprite-list"><div class="jp-empty"><p>Sprites werden geladen …</p></div></div>
            <p class="jp-handbook-source">Grafiken aus der Sprite-Bibliothek der Online-IDE von Martin Pabst.</p>
        </div>`,l.appendChild(t),requestAnimationFrame(()=>t.classList.add("is-open"));const r=t.querySelector(".jp-sprite-list"),p=t.querySelector("input"),o=t.querySelector(".jp-handbook-count"),n=()=>{t.classList.remove("is-open"),document.removeEventListener("keydown",m),setTimeout(()=>t.remove(),200)},m=a=>{a.key=="Escape"&&n()};document.addEventListener("keydown",m),t.querySelector(".jp-handbook-close").addEventListener("click",n),t.addEventListener("click",a=>{a.target==t&&n()});let h;try{h=await w()}catch{r.innerHTML='<div class="jp-empty"><p>Die Sprites konnten nicht geladen werden.</p></div>';return}const f=(a,e)=>{const i=Math.min(L,x/Math.max(e.w,e.h)),s=Math.round(e.w*i),d=Math.round(e.h*i),$=i>1?" is-pixelated":"",g=`new Sprite(100, 150, SpriteLibrary.${a.name}, ${e.index})`;return`<button class="jp-sprite-tile" data-code="${u(g)}" aria-label="${u(a.name)} Nummer ${e.index}">
            <span class="jp-sprite-box"><span class="jp-sprite-img${$}" style="width:${s}px;height:${d}px;
                background-image:url('${v}');
                background-size:${h.sheetW*i}px ${h.sheetH*i}px;
                background-position:${-e.x*i}px ${-e.y*i}px"></span></span>
            <span class="jp-sprite-nr">Nr. ${e.index}</span>
            <span class="jp-sprite-size">${e.w} × ${e.h}</span>
        </button>`},y=()=>{const a=p.value.trim().toLowerCase(),e=h.sets.filter(s=>!a||s.name.toLowerCase().includes(a));r.innerHTML=e.map(s=>`
            <section class="jp-sprite-set">
                <h3><code>SpriteLibrary.${u(s.name)}</code><span>${s.frames.length} ${s.frames.length==1?"Bild":"Bilder"}</span></h3>
                <div class="jp-sprite-grid">${s.frames.map(d=>f(s,d)).join("")}</div>
            </section>`).join("")||`<div class="jp-empty">${b("search")}<p>Keine Reihe gefunden für „${u(p.value.trim())}“.</p></div>`;const i=e.reduce((s,d)=>s+d.frames.length,0);o.textContent=`${e.length} Reihen · ${i} Bilder`};r.addEventListener("click",async a=>{const e=a.target.closest("[data-code]");if(!e)return;const i=e.dataset.code;try{await navigator.clipboard.writeText(i),c(`Kopiert: ${i}`,"check")}catch{c(i,"info")}r.querySelectorAll(".is-copied").forEach(s=>s.classList.remove("is-copied")),e.classList.add("is-copied")});let j;p.addEventListener("input",()=>{clearTimeout(j),j=setTimeout(y,120)}),y()}export{re as builtinSpriteNames,oe as openSpriteLibrary};
