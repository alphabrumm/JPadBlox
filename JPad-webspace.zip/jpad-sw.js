/* JPad Service Worker: macht die App nach dem ersten Laden offline nutzbar.
   Strategie: erst Netz, bei fehlender Verbindung aus dem Zwischenspeicher. */
const CACHE = "jpad-v1";

self.addEventListener("install", () => self.skipWaiting());
self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));

self.addEventListener("fetch", (event) => {
    const req = event.request;
    if (req.method !== "GET" || new URL(req.url).origin !== self.location.origin) return;
    event.respondWith(
        fetch(req).then((res) => {
            if (res.ok) {
                const copy = res.clone();
                caches.open(CACHE).then((c) => c.put(req, copy));
            }
            return res;
        }).catch(() => caches.match(req).then((r) => r || caches.match("./jpad.html")))
    );
});
